package com.example.ac2;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.ac2.models.Diretor;
import com.example.ac2.models.Filme;
import com.example.ac2.repositories.DiretorRepository;
import com.example.ac2.repositories.FilmeRepository;

@SpringBootApplication
public class Ac2Application {

    @Bean
    public CommandLineRunner init(
            @Autowired FilmeRepository filmeRepository,
            @Autowired DiretorRepository diretorRepository) {

        return args -> {

            System.out.println("*** INSERINDO DIRETORES ***");
            Diretor d1 = new Diretor(null, "Christopher Nolan", new ArrayList<>());
            Diretor d2 = new Diretor(null, "Steven Spielberg", new ArrayList<>());

            d1 = diretorRepository.save(d1);
            d2 = diretorRepository.save(d2);

            System.out.println("*** INSERINDO FILMES ***");
            Filme f1 = new Filme(null, "Interestelar", 169, d1);
            Filme f2 = new Filme(null, "A Origem", 148, d1);
            Filme f3 = new Filme(null, "E.T.", 115, d2);
            Filme f4 = new Filme(null, "Tubarão", 124, d2);

            f1 = filmeRepository.save(f1);
            f2 = filmeRepository.save(f2);
            f3 = filmeRepository.save(f3);
            f4 = filmeRepository.save(f4);

            System.out.println("*** FILMES COM DURACAO MAIOR QUE 120 ***");
            List<Filme> filmesMaiorDuracao = filmeRepository.findByDuracaoGreaterThan(120);
            filmesMaiorDuracao.stream()
                    .map(Filme::getTitulo)
                    .forEach(System.out::println);

            System.out.println("*** FILMES COM DURACAO MENOR OU IGUAL A 120 ***");
            List<Filme> filmesMenorOuIgual = filmeRepository.findByDuracaoLessThanEqual(120);
            filmesMenorOuIgual.stream()
                    .map(Filme::getTitulo)
                    .forEach(System.out::println);

            System.out.println("*** FILMES QUE COMECAM COM A LETRA A ***");
            List<Filme> filmesComecamComA = filmeRepository.findByTituloStartingWith("A");
            filmesComecamComA.stream()
                    .map(Filme::getTitulo)
                    .forEach(System.out::println);

            System.out.println("*** DIRETORES QUE COMECAM COM C ***");
            List<Diretor> diretoresComecamComC = diretorRepository.findByNomeStartingWith("C");
            diretoresComecamComC.stream()
                    .map(Diretor::getNome)
                    .forEach(System.out::println);

            System.out.println("*** DIRETOR BUSCADO PELO ID COM SEUS FILMES ***");
            Diretor diretorCompleto = diretorRepository.findDiretorByIdComFilmes(d2.getId());
            System.out.println("Diretor: " + diretorCompleto.getNome());

            diretorCompleto.getFilmes().stream()
                    .map(Filme::getTitulo)
                    .forEach(titulo -> System.out.println("Filme: " + titulo));
        };
    }

    public static void main(String[] args) {
        SpringApplication.run(Ac2Application.class, args);
    }
}
